#include <vcl.h>
#include <stdio.h>

#include <U_Arquivo.h>
#include <U_Calendario.h>

struct struct_Projeto
{
    String Nome;
    String Data;
    int Tamanho;
} Lst_Projeto[10];


void Mostrar_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, int p_Posicao, String p_Nome, String p_Data, Tfrm_Calendario *p_Form )
{
    int H_dia=0, H_mes=0, H_ano=0, H_Prazo=0,
        P_dia=0, P_mes=0, P_ano=0, P_Prazo=0;

    TEdit *nome = new TEdit(p_Painel);
    TEdit *data = new TEdit(p_Painel);
    TPanel *sinal = new TPanel(p_Painel);
    
    nome->Parent = p_Painel;
    nome->OnChange = p_Form->Alarme_Gravar;
    nome->Top = 5 + 20*p_Posicao;
    nome->Left = 5;
    nome->Width = 190;
    nome->Text = p_Nome;
    nome->Tag = p_Posicao;
    nome->Hint = "Nome";

    data->Parent = p_Painel;
    data->OnChange = p_Form->Alarme_Gravar;
    data->Top = 5 + 20*p_Posicao;
    data->Left = 200;
    data->Width = 95;
    data->Text = p_Data;
    data->Tag = p_Posicao;
    data->Hint = "Data";

    /*
    TEdit *tam = new TEdit(p_Painel);
    tam->Parent = p_Painel;
    tam->Top = 5 + 20*p_Posicao;
    tam->Left = 200;
    tam->Width = 95;
    tam->Text = tam;
    tam->Tag = p_Posicao;
    */
    
    sinal->Parent = p_Painel;
    sinal->Top = 5 + 20*p_Posicao;
    sinal->Left = 300;
    sinal->Height = 18;
    sinal->Width = 32;

    sscanf(Now().DateString().c_str(), "%02d/%02d/%04d", &H_dia, &H_mes, &H_ano );
    sscanf(p_Data.c_str(), "%02d/%02d/%04d", &P_dia, &P_mes, &P_ano );

    H_Prazo = H_ano*365+H_mes*30+H_dia;
    P_Prazo = P_ano*365+P_mes*30+P_dia;

         if( (P_Prazo-H_Prazo > 30) ) { sinal->Color = (TColor)RGB(0,255,128); }
    else if( (P_Prazo-H_Prazo > 20) ) { sinal->Color = (TColor)RGB(0,255,0); }
    else if( (P_Prazo-H_Prazo > 10) ) { sinal->Color = (TColor)RGB(255,255,0); }
    else if( (P_Prazo-H_Prazo >  5) ) { sinal->Color = (TColor)RGB(255,128,0); }
    else if( (P_Prazo-H_Prazo == 0) ) { sinal->Color = (TColor)RGB(255,0,0); }
    else { sinal->Color = (TColor)RGB(255,0,0); }
}

void Abrir_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto, Tfrm_Calendario *p_Form )
{

    int quant = 0,
        cont  = 0;

    Abrir_Arquivo( p_Painel, p_Lst_Projeto );

    TPanel *painel = new TPanel(p_Painel);
    painel->Parent = p_Painel;
    painel->Name = "Lst_Projetos";
    painel->Caption = "";
    painel->Align = alClient;

    quant = p_Painel->Tag;
    while(cont<quant)
    {
        Mostrar_Projeto( p_Bto_Salvar, painel, cont, p_Lst_Projeto[cont].Nome, p_Lst_Projeto[cont].Data, p_Form );
        cont++;
    }
}

void Incluir_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto, String p_Nome, String p_Data, Tfrm_Calendario *p_Form )
{
    int cont = p_Painel->Tag;
    p_Lst_Projeto[cont].Nome = p_Nome;
    p_Lst_Projeto[cont].Data = p_Data;
    p_Painel->Tag++;

    Mostrar_Projeto( p_Bto_Salvar, p_Painel, cont, p_Nome, p_Data, p_Form );
}

void Salvar_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto)
{
    Salvar_Arquivo( p_Painel, p_Lst_Projeto );
}

void Atualiza_Projeto( struct struct_Projeto *p_Lst_Projeto, TEdit *p_Edit )
{
    int pos = p_Edit->Tag;

    if ( p_Edit->Hint == "Nome" )
    {
        p_Lst_Projeto[pos].Nome = p_Edit->Text;
    }
    else
    {
        p_Lst_Projeto[pos].Data = p_Edit->Text;
    }
}

