#include <U_Calendario.h>

void Abrir_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto, Tfrm_Calendario *p_Form );

void Incluir_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto, String p_Nome, String p_Data, Tfrm_Calendario *p_Form );

void Salvar_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto);

void Mostrar_Projeto( TButton *p_Bto_Salvar, TPanel *p_Painel, int p_Posicao, String p_Nome, String p_Data, Tfrm_Calendario *p_Form );

void Atualiza_Projeto( struct struct_Projeto *p_Lst_Projeto, TEdit *p_Edit );
