
void Diretorio();

int Salvar_Arquivo( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto );

int Abrir_Arquivo( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto );
 
