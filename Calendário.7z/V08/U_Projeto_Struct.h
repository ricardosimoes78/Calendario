
#ifndef struct_Projeto_H
#define struct_Projeto_H
    typedef struct struct_Projeto
    {
        String Nome;
        String Data_Entrega;
        String Data_Alteracao;
        int Tamanho;
    } Tp_Projeto;
#endif
 