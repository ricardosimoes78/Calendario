
#ifndef struct_Agenda_H
#define struct_Agenda_H
    typedef struct struct_Agenda
    {
        String Domingo[9];
        String Segunda[9];
        String Terca[9];
        String Quarta[9];
        String Quinta[9];
        String Sexta[9];
        String Sabado[9];
    } Tp_Agenda;
#endif
 