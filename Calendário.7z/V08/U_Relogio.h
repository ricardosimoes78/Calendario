#ifndef Base_CPP_H
#define Base_CPP_H
    #include <vcl.h>
    #include <stdio.h>
    #include <dirent.h>
    #include <time.h>
#endif

TColor Fundo(int p_Hora);

void Horarios( TPanel *p_Painel );
 