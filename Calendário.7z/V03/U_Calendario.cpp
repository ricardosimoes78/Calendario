//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#include <time.h>
#pragma hdrstop

#include "U_Calendario.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

int dia; int mes; int ano;
int hora; int min; int seg;

TColor Fundo(int p_Hora)
{
    int Vermelho[24]={28,34,36,28,36,37,30,28,27,115,161,213,255,253,249,245,237,236,234,219,172,116,93,44},
        Verde[24]   ={28,36,62,80,118,153,166,171,180,197,213,233,250,226,196,140,94,55,26,3,27,41,38,34},
        Azul[24]    ={76,94,132,150,192,196,160,148,146,147,156,168,165,166,165,150,107,95,97,121,121,111,100,89};
//    int Hora_Ref=0;


    return (TColor)RGB(Vermelho[p_Hora],Verde[p_Hora],Azul[p_Hora]);
    /*
    Hora_Ref=6;
    if (p_Hora <= Hora_Ref) { Azul = 255; Vermelho = 0; if (p_Hora>0) { Verde = 255*(p_Hora/6.0); } return RGB(Vermelho,Verde,Azul); }

    Hora_Ref=12;
    if (p_Hora <= Hora_Ref) { Azul = 255-255*((6-(Hora_Ref-p_Hora))/6.0); Vermelho = 0; Verde = 255; return RGB(Vermelho,Verde,Azul); }

    Hora_Ref=18;
    if (p_Hora <= Hora_Ref) { Azul  = 0; Vermelho = 255*((6-(Hora_Ref-p_Hora))/6.0); Verde = 255; return RGB(Vermelho,Verde,Azul); }

    Hora_Ref=18;
    if (p_Hora > Hora_Ref) { Azul = 0; Vermelho = 255; Verde = 255-255*((6-(Hora_Ref-p_Hora))/6.0); return RGB(Vermelho,Verde,Azul); }
    */
}

Tfrm_Calendario *frm_Calendario;
//---------------------------------------------------------------------------
__fastcall Tfrm_Calendario::Tfrm_Calendario(TComponent* Owner): TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall Tfrm_Calendario::FormShow(TObject *Sender)
{

    Calendario->Font->Name = "Verdana";
    Calendario->Font->Size = 20;
    Calendario->Date = Now();

    lbl_Data->Height = 30;
    lbl_Data->Top = 9;
    lbl_Data->Left = 152;
    lbl_Data->Font->Name = "Courier New";
    lbl_Data->Font->Size = 20;
    lbl_Data->Font->Color = clGreen;
    pnl_Data->Height = 50;
    pnl_Data->Top = 0;
    pnl_Data->Left = 0;

    lbl_Horario->Height = 30;
    lbl_Horario->Top = 9;
    lbl_Horario->Left = 152;
    lbl_Horario->Font->Name = "Courier New";
    lbl_Horario->Font->Size = 20;
    lbl_Horario->Font->Color = clGreen;
    pnl_Horario->Height = 50;
    pnl_Horario->Top = 0;
    pnl_Horario->Left = 0;
    pnl_Horario->BevelOuter = bvNone;

    lbl_Data->Caption = Calendario->Date;
    sscanf(lbl_Data->Caption.c_str(), "%02d/%02d/%04d %02d:%02d:%02d", &dia, &mes, &ano, &hora, &min, &seg );

    this->ControleTimer(Sender);
}
//---------------------------------------------------------------------------
void __fastcall Tfrm_Calendario::ControleTimer(TObject *Sender)
{
    char relogio[256];

    seg++;
    if (seg==60) { seg=0; min++; }
    if (min==60) { min=0; hora++; }
    if (hora==24) { hora=0; dia++; }
    //if (dia==31) { dia=1; mes++; }
    //if (mes==13) { mes=1; ano++; }

    sprintf(relogio, "%02d:%02d:%02d", hora, min, seg);
    this->lbl_Data->Caption = relogio;
    this->lbl_Horario->Caption = relogio;

    //pnl_Data->Color = Fundo(hora);
    this->pnl_Horario->Color = Fundo(hora);
    this->pnl_Horario->Width = (hora+((float)min/60))/24 * this->pnl_Data->Width;

}
//---------------------------------------------------------------------------
