//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#include <time.h>
#pragma hdrstop

#include "U_Calendario.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

int dia; int mes; int ano;
int hora; int min; int seg;

TColor Fundo(int p_Hora)
{
    if (p_Hora <= 12) return clLime;
    if (p_Hora <= 12) return clAqua;
    if (p_Hora <= 18) return clYellow;
    if (p_Hora >  18) return clBlue;
}

Tfrm_Calendario *frm_Calendario;
//---------------------------------------------------------------------------
__fastcall Tfrm_Calendario::Tfrm_Calendario(TComponent* Owner): TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall Tfrm_Calendario::FormShow(TObject *Sender)
{

    Calendario->Font->Name = "Verdana";
    Calendario->Font->Size = 20;
    Calendario->Date = Now();

    lbl_Data->Font->Name = "Courier New";
    lbl_Data->Font->Size = 20;
    lbl_Data->Font->Color = clGreen;

    lbl_Data->Caption = Calendario->Date;
    sscanf(lbl_Data->Caption.c_str(), "%i/%i/%i %i:%i:%i", &dia, &mes, &ano, &hora, &min, &seg );
}
//---------------------------------------------------------------------------
void __fastcall Tfrm_Calendario::ControleTimer(TObject *Sender)
{
    char relogio[256];

    seg++;
    if (seg==60) { seg=0; min++; }
    if (min==60) { min=0; hora++; }
    if (hora==24) { hora=0; dia++; }
    //if (dia==31) { dia=1; mes++; }
    //if (mes==13) { mes=1; ano++; }

    sprintf(relogio, "%02d:%02d:%02d", hora, min, seg);
    lbl_Data->Caption = relogio;

    pnl_Data->Color = Fundo(hora);
}
//---------------------------------------------------------------------------
