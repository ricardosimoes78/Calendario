
TColor Fundo(int p_Hora);
 