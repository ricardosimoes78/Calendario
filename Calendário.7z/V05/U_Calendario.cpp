//---------------------------------------------------------------------------

#include <vcl.h>
#include <stdio.h>
#include <time.h>

#include <U_Projeto.h>
#include <U_Relogio.h>

#pragma hdrstop

#include "U_Calendario.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"

int dia; int mes; int ano;
int hora; int min; int seg;

extern Lst_Projeto[10];

Tfrm_Calendario *frm_Calendario;
//---------------------------------------------------------------------------
__fastcall Tfrm_Calendario::Tfrm_Calendario(TComponent* Owner): TForm(Owner)
{
}
//---------------------------------------------------------------------------

void __fastcall Tfrm_Calendario::FormShow(TObject *Sender)
{
    this->Projeto->Tag = 0;
    Abrir_Projeto( this->Projeto, (struct struct_Projeto *)Lst_Projeto );

    Calendario->Date = Now();
    Calendario->Font->Name = "Verdana";
    Calendario->Font->Size = 20;
    Calendario->Top = 56;
    Calendario->Left = 8;
    Calendario->Height = 353;
    Calendario->Width = 428;

    lbl_Data->Height = 30;
    lbl_Data->Top = 9;
    lbl_Data->Left = 152;
    lbl_Data->Font->Color = clGreen;
    lbl_Data->Font->Name = "Courier New";
    lbl_Data->Font->Size = 20;

    pnl_Data->Height = 50;
    pnl_Data->Top = 0;
    pnl_Data->Left = 0;

    lbl_Horario->Height = 30;
    lbl_Horario->Top = 9;
    lbl_Horario->Left = 152;
    lbl_Horario->Font->Color = clGreen;
    lbl_Horario->Font->Name = "Courier New";
    lbl_Horario->Font->Size = 20;

    pnl_Horario->Height = 50;
    pnl_Horario->Top = 0;
    pnl_Horario->Left = 0;
    pnl_Horario->BevelOuter = bvNone;

    lbl_Data->Caption = Calendario->Date;
    sscanf(lbl_Data->Caption.c_str(), "%02d/%02d/%04d %02d:%02d:%02d", &dia, &mes, &ano, &hora, &min, &seg );

    this->ControleTimer(Sender);

}
//---------------------------------------------------------------------------
void __fastcall Tfrm_Calendario::ControleTimer(TObject *Sender)
{
    char relogio[256];

    seg++;
    if (seg==60) { seg=0; min++; }
    if (min==60) { min=0; hora++; }
    if (hora==24) { hora=0; dia++; }

    sprintf(relogio, "%02d:%02d:%02d", hora, min, seg);
    this->lbl_Data->Caption = relogio;
    this->lbl_Horario->Caption = relogio;

    this->pnl_Horario->Color = Fundo(hora);
    this->pnl_Horario->Width = (hora+((float)min/60))/24 * this->pnl_Data->Width;

}
//---------------------------------------------------------------------------
void __fastcall Tfrm_Calendario::bto_IncProjetoClick(TObject *Sender)
{

    Incluir_Projeto(this->Projeto, (struct struct_Projeto *)Lst_Projeto, this->edt_IncProjeto->Text, this->edt_DataProjeto->Text);
}
//---------------------------------------------------------------------------

void __fastcall Tfrm_Calendario::bto_SalvarClick(TObject *Sender)
{
    Salvar_Projeto(this->Projeto, (struct struct_Projeto *)Lst_Projeto);
}
//---------------------------------------------------------------------------

