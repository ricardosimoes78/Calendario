

void Abrir_Projeto( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto );

void Incluir_Projeto( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto, String p_Nome, String p_Data );

void Salvar_Projeto( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto);

void Mostrar_Projeto( TPanel *p_Painel, int p_Posicao, String p_Nome, String p_Data );
 