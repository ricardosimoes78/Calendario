#include <vcl.h>
#include <stdio.h>

#include <U_Arquivo.h>


struct struct_Projeto
{
    String Nome;
    String Data;
} Lst_Projeto[10];

  
void Mostrar_Projeto( TPanel *p_Painel, int p_Posicao, String p_Nome, String p_Data )
{
    TLabel *nome = new TLabel(p_Painel);
    nome->Parent = p_Painel;
  //nome->OnClick = &ButtonClicked;
    nome->Top = 5 + 20*p_Posicao;
    nome->Left = 5;
    nome->Caption = p_Nome;

    TLabel *data = new TLabel(p_Painel);
    data->Parent = p_Painel;
    data->Top = 5 + 20*p_Posicao;
    data->Left = 200;
    data->Caption = p_Data;

    TPanel *painel = new TPanel(p_Painel);
    painel->Parent = p_Painel;
    painel->Top = 5 + 20*p_Posicao;
    painel->Left = 300;
    painel->Height = 18;
    painel->Width = 32;

    int H_dia=0, H_mes=0, H_ano=0,
        P_dia=0, P_mes=0, P_ano=0;

    sscanf(Now().DateString().c_str(), "%02d/%02d/%04d", &H_dia, &H_mes, &H_ano );
    sscanf(p_Data.c_str(), "%02d/%02d/%04d", &P_dia, &P_mes, &P_ano );

         if( (H_ano*365+H_mes*30+H_dia) < (P_ano*365+P_mes*30+P_dia) ) { painel->Color = RGB(0,255,0); }
    else if( (H_ano*365+H_mes*30+H_dia) == (P_ano*365+P_mes*30+P_dia) ) { painel->Color = RGB(255,255,0); }
    else { painel->Color = RGB(255,0,0); }
}

void Abrir_Projeto( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto )
{
    int quant = 0,
        cont  = 0;

    Abrir_Arquivo( p_Painel, p_Lst_Projeto );

    quant = p_Painel->Tag;
    while(cont<quant)
    {
        Mostrar_Projeto( p_Painel, cont, p_Lst_Projeto[cont].Nome, p_Lst_Projeto[cont].Data );
        cont++;
    }
}

void Incluir_Projeto( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto, String p_Nome, String p_Data )
{
    int cont = p_Painel->Tag;
    p_Lst_Projeto[cont].Nome = p_Nome;
    p_Lst_Projeto[cont].Data = p_Data;
    p_Painel->Tag++;

    Mostrar_Projeto( p_Painel, cont, p_Nome, p_Data );

}

void Salvar_Projeto( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto)
{
    Salvar_Arquivo( p_Painel, p_Lst_Projeto );

}


