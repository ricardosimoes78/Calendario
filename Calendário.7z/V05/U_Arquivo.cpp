#include <stdio.h>
#include <vcl.h>

struct struct_Projeto
{
    String Nome;
    String Data;
};

int Salvar_Arquivo( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto )
{
    FILE *arquivo = NULL;
    char  nome[256], data[16];
    int quant=p_Painel->Tag, cont=0, tam=0;

    arquivo = fopen( "projeto.txt", "w" );
    if( arquivo != NULL )
    {
        while (cont<quant)
        {
            tam += fprintf(arquivo, "%s %s\n\0", p_Lst_Projeto[cont].Nome, p_Lst_Projeto[cont].Data);
            cont++;
        }
    }

    fclose (arquivo);

    return tam;
}


int Abrir_Arquivo( TPanel *p_Painel, struct struct_Projeto *p_Lst_Projeto )
{
    FILE *arquivo = NULL;
    char  nome[256], data[16];
    int tam=0, cont=0;

    arquivo = fopen( "projeto.txt", "r" );
    if( arquivo != NULL )
    {
        while ( fscanf(arquivo, "%s %s", nome, data) > 0) //!feof(arquivo))
        {
            //tam += fscanf(arquivo, "%s %s", nome, data);
            p_Lst_Projeto[cont].Nome = nome;
            p_Lst_Projeto[cont].Data = data;
            cont++;
        }

        p_Painel->Tag = cont;
    }

    fclose (arquivo);

    return tam;
}


/*

#include <iostream>
#include <string>
#include <filesystem>
using namespace std;
using namespace std::tr2::sys;

void  getFoldersize(string rootFolder,unsigned long long & f_size)
{
   path folderPath(rootFolder);                      
   if (exists(folderPath))
   {
        directory_iterator end_itr;
        for (directory_iterator dirIte(rootFolder); dirIte != end_itr; ++dirIte )
        {
            path filePath(complete (dirIte->path(), folderPath));
           try{
                  if (!is_directory(dirIte->status()) )
                  {
                      f_size = f_size + file_size(filePath);                      
                  }else
                  {
                      getFoldersize(filePath,f_size);
                  }
              }catch(exception& e){  cout << e.what() << endl; }
         }
      }
    }

int main()
{
    unsigned long long  f_size=0;
    getFoldersize("C:\\Silvio",f_size);
    cout << f_size << endl;
    system("pause");
    return 0;
}

*/