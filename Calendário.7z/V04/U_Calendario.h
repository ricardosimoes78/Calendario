//---------------------------------------------------------------------------

#ifndef U_CalendarioH
#define U_CalendarioH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class Tfrm_Calendario : public TForm
{
__published:	// IDE-managed Components
    TMonthCalendar *Calendario;
    TTimer *Controle;
    TPanel *pnl_Data;
    TLabel *lbl_Data;
    TPanel *pnl_Horario;
    TLabel *lbl_Horario;
    TBevel *Bevel1;
    TPanel *Projeto;
    TButton *bto_IncProjeto;
    TEdit *edt_IncProjeto;
        void __fastcall FormShow(TObject *Sender);
    void __fastcall ControleTimer(TObject *Sender);
    void __fastcall bto_IncProjetoClick(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall Tfrm_Calendario(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE Tfrm_Calendario *frm_Calendario;
//---------------------------------------------------------------------------
#endif
